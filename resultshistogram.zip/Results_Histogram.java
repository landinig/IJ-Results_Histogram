import ij.*;
import ij.gui.*;
import ij.process.*;
import ij.plugin.PlugIn;
import ij.plugin.*;
import ij.measure.*;
import java.util.*;
// G. Landini at bham. ac. uk
// 18 May 2005
// Reads the data from the ResultsTable and plots a frequency histogram
public class Results_Histogram implements PlugIn {

	public void run(String arg) {
		ResultsTable rt=ResultsTable.getResultsTable();
		int count = rt.getCounter();
        //IJ.log(""+count);
		String head= rt.getColumnHeadings();
		//IJ.log(head);

		StringTokenizer t = new StringTokenizer(head, "\t");
		int tokens = t.countTokens()-1;
		String[] strings = new String[tokens];
		strings[0] = t.nextToken(); // first token is empty?
	   	for(int i=0; i<tokens; i++){
			strings[i] = t.nextToken();
			//IJ.log(strings[i]);
		}

		GenericDialog gd = new GenericDialog("Histogram", IJ.getInstance());
		gd.addMessage("Explore the Results Table");
		gd.addChoice("Variables", strings, strings[0]);
		gd.addMessage("Data points: "+ count);
		gd.addCheckbox("Automatic binning",true);
		gd.addNumericField ("or specify bins", 10, 0);
		gd.addCheckbox("Log results",false);



		gd.showDialog();
		//if (gd.wasCanceled())
		//	return DONE;

		String sOption = gd.getNextChoice ();
		boolean aBins = gd.getNextBoolean();
		int nBins = (int)gd.getNextNumber();
		boolean log = gd.getNextBoolean();

		//int nBins =5;
		float[] data = rt.getColumn(rt.getColumnIndex(sOption));

		float [] pars = new float [11];
		stats(count, data, pars);
		if (log) {
		IJ.log("Param: "+sOption);
		IJ.log("Data: "+ pars[1]);
		IJ.log("Sum: "+pars[2]);
		IJ.log("Min: "+pars[3]);
		IJ.log("Max: "+pars[4]);
		IJ.log("Mean: "+pars[5]);
		IJ.log("AvDev: "+pars[6]);
		IJ.log("StDev: "+pars[7]);
		IJ.log("Var: "+pars[8]);
		IJ.log("Skew: "+pars[9]);
		IJ.log("Kurt: "+pars[10]);
		IJ.log(" ");
		}
		if (aBins) {
			//sd = 7, min = 3, max = 4
			// use Scott's method (1979 Biometrika, 66:605-610) for optimal binning: 3.49*sd*N^-1/3
			float binWidth = (float)(3.49 * pars[7]*(float)Math.pow((float)count, -1.0/3.0));
			nBins= (int)Math.floor(((pars[4]-pars[3])/binWidth)+.5);
		}

		ImageProcessor ip = new FloatProcessor(count, 1, data, null);
		new HistogramWindow(sOption+" Distribution", new ImagePlus("",ip), nBins);

	}

	void stats(int nc, float [] data, float [] pars){
 // ("\tPoints\tEdges_n\tGraph_Length\tMin\tMax\tMean\tAvDev\tSDev\tVar\tSkew\tKurt");
		int i;
		float s = 0, min = Float.MAX_VALUE, max = -Float.MAX_VALUE, totl=0, ave=0, adev=0, sdev=0, var=0, skew=0, kurt=0, p;

		for(i=0;i<nc;i++){
			totl+= data[i];
			//tot& = tot& + 1
				if(data[i]<min) min = data[i];
			if(data[i]>max) max = data[i];
		}

		ave = totl/nc;

		for(i=0;i<nc;i++){
			s = data[i] - ave;
			adev+=Math.abs(s);
			p = s * s;
			var+= p;
			p*=s;
			skew+= p;
			p*= s;
			kurt+= p;
		}

		adev/= nc;
		var/=nc-1;
		sdev = (float) Math.sqrt(var);

		if(var> 0){
			skew = (float)skew / (nc * (float) Math.pow(sdev,3));
			kurt = (float)kurt / (nc * (float) Math.pow(var, 2)) - 3;
		}
		pars[1]=(float) nc;
		pars[2]=totl;
		pars[3]=min;
		pars[4]=max;
		pars[5]=ave;
		pars[6]=adev;
		pars[7]=sdev;
		pars[8]=var;
		pars[9]=skew;
		pars[10]=kurt;

	}

}
